package com.rest.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.servlet.ModelAndView;

import com.rest.model.Employee;

@RestController
public class EmployeeRestClient {


	@RequestMapping("/home")
	public String home() {

		return "home";
	}


	@RequestMapping(value="/addEmp", method=RequestMethod.GET) 
	public  ModelAndView loadAddEmployee() {

		//ModelAndView mav = new ModelAndView("addEmp");
		ModelAndView mav = new ModelAndView(); 
		mav.setViewName("addEmp"); mav.addObject("emp", new Employee()); 
		return mav; 
	}



	@RequestMapping(value="/addEmp", method=RequestMethod.POST)
	public ModelAndView addEmployee(@ModelAttribute("emp") Employee emp) {

		RestTemplate restTemplate = new RestTemplate();
		String url="http://localhost:3456/employees/";
		HttpEntity<Employee> request = new HttpEntity<>(emp);
		String message = restTemplate.postForObject(url, request, String.class);
		ModelAndView mav = new ModelAndView("addEmp");		
		mav.addObject("successMessage", message);
		return mav;
	}

	@RequestMapping(value="/dispAllEmps", method=RequestMethod.GET) 
	public ModelAndView getEmloyees() {
		List<Employee> list =(List<Employee>) new RestTemplate().getForObject("http://localhost:3456/employees/", List.class);

		ModelAndView mav = new ModelAndView("dispAllEmps");
		if(list.isEmpty()) {
			mav.addObject("errorMessage", "Employee details not found"); 
		} else {
			mav.addObject("empList",list);
		}
		return mav;
	}

	@RequestMapping(value="/dispEmpById", method=RequestMethod.GET) 
	public ModelAndView loadGetEmployeeById() { 
		ModelAndView mav = new ModelAndView("dispEmpById"); 
		return mav; 
	}

	@RequestMapping(value="/dispEmpById", method=RequestMethod.POST) 
	public ModelAndView getEmployeeById(@RequestParam("empId") Integer eid) { 
		ModelAndView  mav = new ModelAndView("dispEmpById"); 
		 ResponseEntity<Employee> e=null;
		try{
			RestTemplate restTemplate = new RestTemplate();		
        String url = "http://localhost:3456/employees/{empId}";
        Map<String, String> params = new HashMap<String, String>();
        params.put("empId", eid.toString());
		//Employee e = new RestTemplate().getForObject(url,Employee.class,params);
       e = restTemplate.getForEntity(url, Employee.class, params);		
				  
		 mav.addObject("emp", e.getBody()); 
		}catch(Exception ex) {
			if(ex.getMessage().contains("502"))
				mav.addObject("errorMessage","Employee details not found for the given employee id");
			else
				mav.addObject("errorMessage","some error occured");
				
		}
		
		return mav; 
	}


}
