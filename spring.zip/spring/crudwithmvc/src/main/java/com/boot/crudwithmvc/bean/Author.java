package com.boot.crudwithmvc.bean;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Author {
@Id
	private String authName;
	private Integer authId;
	private String authBook;
	public String getAuthName() {
		return authName;
	}
	public void setAuthName(String authName) {
		this.authName = authName;
	}
	public Integer getAuthId() {
		return authId;
	}
	public void setAuthId(Integer authId) {
		this.authId = authId;
	}
	public String getAuthBook() {
		return authBook;
	}
	public void setAuthBook(String authBook) {
		this.authBook = authBook;
	}
}
