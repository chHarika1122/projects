package com.boot.crudwithmvc.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.boot.crudwithmvc.bean.Author;

@Service  
public class AuthorService {
	@Autowired 
	      
	    private UserRepository userRepository;  
	    public List<Author> getAllAuthors(){  
	        List<Author>author = new ArrayList<>();  
	        userRepository.findAll().forEach(author::add);  
	        return author;  
	    }  
	    public void addUser(Author author){  
	        userRepository.save(author);  
	    }  
}
