package com.boot.crudwithmvc.controller;

import org.springframework.data.repository.CrudRepository;

import com.boot.crudwithmvc.bean.Author;

public interface UserRepository extends CrudRepository<Author,String> {
//methods are declared also queries
}
