package com.rest.restempclient.controller;

import org.springframework.http.HttpEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.servlet.ModelAndView;

import com.rest.restempclient.model.Employee;

@Controller
public class RestClientController {

	@RequestMapping("/")
	public String getHome() {
		return "index";
	}
	@RequestMapping("/addEmp")
	public String addEmployee(Model model) {
		model.addAttribute("emp",new Employee());
		return "addEmp";
	}
	@RequestMapping(value="/addEmp", method=RequestMethod.POST)
	public ModelAndView addEmp(@ModelAttribute("emp") Employee emp) {
		//return "addEmp";
		String url="http://localhost:1212/employees";
		RestTemplate rt=new RestTemplate();
		HttpEntity<Employee>request=new HttpEntity<Employee>(emp);
		String message=rt.postForObject(url,request,String.class);
		System.out.println("response"+message);
		ModelAndView mv=new ModelAndView("addEmp");
		mv.addObject("successMessage",message);
		return mv;
	}
}
