package com.emp.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
//import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.emp.model.Employee;
import com.emp.service.EmployeeService;

@Controller
public class EmployeeController {
	@Autowired
	EmployeeService service;
	
	@RequestMapping("/home")
	public String home() {
		System.out.println("inside home");
		return "home";
	}
	
	
	  @RequestMapping(value="/addEmp", method=RequestMethod.GET) 
	  public ModelAndView loadAddEmployee() 
	  {
	  //ModelAndView mav = new ModelAndView("addEmp");
		  ModelAndView mav = new ModelAndView(); 
		  mav.setViewName("addEmp");
		  mav.addObject("emp", new Employee()); 
		  return mav; 
	  }
	 
	/*
	 * @RequestMapping(value="/addEmp", method=RequestMethod.GET) public String
	 * loadAddEmployee(ModelMap model) { model.addAttribute("emp",new Employee());
	 * model.put("msg", "first messge"); return "addEmp"; }
	 */
	
	@RequestMapping(value="/addEmp", method=RequestMethod.POST)
	public ModelAndView addEmployee(@ModelAttribute("emp") Employee emp) {
		
		service.insertEmployee(emp);
		ModelAndView mav = new ModelAndView("addEmp");
		String message = "Employee Added Successfully with employee id "+emp.getEmpId();
		mav.addObject("successMessage", message);
		return mav;
	}
	@RequestMapping(value="/dispAllEmps", method=RequestMethod.GET)
	public ModelAndView getEmloyees() {
		List<Employee> list = service.getEmployoees();
		ModelAndView mav = new ModelAndView("dispAllEmps");
		if(list.isEmpty()) {
			mav.addObject("errorMessage", "Employee details not found");			
		}
		else {
			mav.addObject("empList",list);			
		}
		
		return mav;
	}
	@RequestMapping(value="/dispEmpById", method=RequestMethod.GET)
	public ModelAndView loadGetEmployeeById() {			
		ModelAndView mav = new ModelAndView("dispEmpById");		
		return mav;
	}
	
	@RequestMapping(value="/dispEmpById", method=RequestMethod.POST)
	public ModelAndView getEmployeeById(@RequestParam Integer empId) {
		Employee e = service.findEmployee(empId);
		System.out.println("found = "+e);
		ModelAndView mav = new ModelAndView("dispEmpById");	
		if(e!=null) {
			mav.addObject("emp", e);
		}
		else
			mav.addObject("errorMessage","Employee details not found for the given employee id");
		
		return mav;
	}
	@RequestMapping(value="/deleteEmp", method=RequestMethod.GET)
	public ModelAndView loaddeleteEmp() {
		ModelAndView mv=new ModelAndView("deleteEmp");
		return mv;
	}
	
	@RequestMapping(value="/deleteEmp", method=RequestMethod.POST)
	public ModelAndView deleteEmp(@RequestParam Integer empId) {
		Employee e=service.findEmployee(empId);
		ModelAndView mv=new ModelAndView("deleteEmp");
		if(e!=null) {
			service.removeEmployee(empId);
			String message="Employee deleted successfully";
			mv.addObject("successmessage",message);
		}
		else
			mv.addObject("errorMessage","Employee details not found");
		return mv;
	}
	
	@RequestMapping(value="/updateEmp", method=RequestMethod.GET)
	public ModelAndView loadUpdateEmp() {
		ModelAndView mv=new ModelAndView("updateEmp");
		mv.setViewName("updateEmp");
		  mv.addObject("emp", new Employee());
		return mv;
	}
	@RequestMapping(value="/updateEmp", method=RequestMethod.POST)
	public ModelAndView updateEmp(@ModelAttribute("emp") Employee emp, @RequestParam Integer empId) {
		Employee e=service.findEmployee(empId);
		ModelAndView mv=new ModelAndView("updateEmp");
		if(e!=null) {
			service.updateEmployee(empId,emp);
			String message="Employee updated successfully";
			mv.addObject("successmessage",message);
		
		}
		else
			mv.addObject("errorMessage","employee details not found");
		return mv;
	}
	
}
