package com.cg.jpa.service;

import com.cg.jpa.model.Author;

public  interface ServiceInterface
{
		void addAuthor(Author a);
		void deleteAuthor(int id);
		void updateAuthor(int id, String fname);
		void getAuthor(int id);
		
}

	
