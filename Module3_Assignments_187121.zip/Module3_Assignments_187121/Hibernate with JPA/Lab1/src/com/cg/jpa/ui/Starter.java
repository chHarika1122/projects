package com.cg.jpa.ui;
import java.util.Scanner;

import com.cg.jpa.dao.AuthorDao;
import com.cg.jpa.model.Author;
public class Starter {
	public static void main(String args[])
	{
		while(true)
		{
			System.out.println("1.Add Author");
			System.out.println("2.Get Author");
			System.out.println("3.Update Author");
			System.out.println("4.Delete Author");
			System.out.println("5.Exit");
			System.out.println("Enter your choice");
			Scanner s=new Scanner(System.in);
			int choice=s.nextInt();
			AuthorDao ad=new AuthorDao();
			Author a=new Author();
			
			switch(choice)
			{
			case 1:
			{
				System.out.println("enter the firstname");
				String fname=s.next();
				System.out.println("enter the middlename");
				String mname=s.next();
				System.out.println("enter the lastname");
				String lname=s.next();
				System.out.println("enter the phoneno");
				Long phoneno=s.nextLong();
				a.setFirstName(fname);
				a.setMiddleName(mname);
				a.setLastName(lname);
				a.setPhoneNo(phoneno);
				ad.addAuthor(a);
				break;
			}
			case 2:
			{
				System.out.println("Enter the id");
				int id=s.nextInt();
				ad.getAuthor(id);
				break;
			}
			case 3:
			{
				System.out.println("Enter the id");
				int id=s.nextInt();
				System.out.println("enter the firstname");
				String fname=s.next();
				ad.updateAuthor(id,fname);
				break;
			}
			case 4:
			{
				System.out.println("Enter the id");
				int id=s.nextInt();
				ad.deleteAuthor(id);
				break;
			}
			case 5:
			{
				System.exit(0);
				break;
			}
			default:
				System.out.println("Invalid choice");
		}
		}
	}
}



