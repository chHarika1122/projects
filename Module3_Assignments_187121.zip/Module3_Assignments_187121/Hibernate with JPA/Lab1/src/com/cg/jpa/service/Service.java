package com.cg.jpa.service;

import com.cg.jpa.dao.AuthorDao;
import com.cg.jpa.model.Author;

public class Service implements ServiceInterface
{
	
	AuthorDao dao=new AuthorDao();
	public void addAuthor(Author a)
	{
		dao.addAuthor(a);
	}

	@Override
	public void deleteAuthor(int id)
	{		
		dao.deleteAuthor(id);
	}

	@Override
	public void updateAuthor(int id,String fname)
	{
		dao.updateAuthor(id,fname);
	}

	@Override
	public  void getAuthor(int id)
	{
		dao.getAuthor(id);
	}

}

